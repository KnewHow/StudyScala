package com.qiniu.streaming.model;

/**
 * Created by bailong on 16/9/22.
 */
public final class StreamAttribute {
    public long createdAt;
    public long updatedAt;
    public long expireAt;
    public long disabledTill;
}
